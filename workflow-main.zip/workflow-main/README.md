# Review Desk

A requirement goes in. The service turns it into a task graph, runs that graph, and stops for a person on high-impact steps. You drive it with HTTP. Nothing in this guide uses a browser UI.

The server listens on **http://localhost:8080**. Every path below is under **`/api/v1`**.

## Prerequisites (Windows)

1. **JDK 21** (Eclipse Temurin 21). After install, set a user environment variable:

   `JAVA_HOME` = `C:\Program Files\Eclipse Adoptium\jdk-21...`

   Add `%JAVA_HOME%\bin` to `Path`. Open a new PowerShell and check:

   ```powershell
   java -version
   ```

   The first line must say version 21.

2. **Git for Windows**, on `Path`. Required when a run writes code (`desk.executor=agent`).

3. **Apache Maven 3.9+**, on `Path` as `mvn.cmd`. Required only for agent mode. The server itself uses the Maven wrapper (`mvnw.cmd`) and does not need a separate Maven install to start.

   ```powershell
   git --version
   mvn -version
   ```

Use a normal user account. Do not start the build from an elevated Administrator prompt.

## Start

```powershell
cd C:\path\to\workflow\desk
.\mvnw.cmd spring-boot:run
```

Wait until the log contains `Started DeskApplication`. Leave this window open.

Default mode is **simulated**: the graph, gates, and approvals run, and no project files are written. To generate the URL shortener, compile it, test it, and commit each step, stop the server and start again with:

```powershell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.arguments=--desk.executor=agent --desk.node-timeout-ms=900000"
```

`--desk.node-timeout-ms=900000` keeps a real Maven build from being killed at the 30 second default.

Stop the server with Ctrl+C. To drop saved runs, stop the server first, then delete the `desk\data` folder.

## Calling the API from PowerShell

```powershell
$base = "http://localhost:8080/api/v1"

function Post-Json($path, $obj) {
  Invoke-RestMethod -Method Post -Uri "$base$path" -ContentType "application/json" -Body ($obj | ConvertTo-Json)
}
```

## Walkthrough

### 1. Confirm the host

```powershell
Invoke-RestMethod "$base/host"
```

`family` is `windows`. `maven` is `mvn.cmd`.

### 2. New system (greenfield)

Decompose first. This does not start work.

```powershell
$plan = Post-Json "/decompose" @{
  requirement  = "Build a URL shortener service with shorten and redirect APIs"
  scenarioHint = "GREENFIELD"
}
$plan.summary
$plan.plan.id
```

`summary` includes the scenario, task count, tasks that need a person, and high-risk tasks. Admit that exact plan:

```powershell
$run = Post-Json "/runs" @{
  planId         = $plan.plan.id
  autonomyLevel  = "L2_DELEGATED"
}
$run.id
```

`POST /runs` returns **202**. Poll until it needs you or it finishes:

```powershell
Invoke-RestMethod "$base/runs/$($run.id)"
Invoke-RestMethod "$base/approvals?runId=$($run.id)"
```

Approve each pending item (use the `id` from the approval list):

```powershell
Invoke-RestMethod -Method Post -Uri "$base/approvals/<approval-id>/approve?decidedBy=yourname&note=reviewed"
```

Repeat until `status` is `COMPLETED`.

In agent mode the generated project is `desk\workspace\<run-id>`. In that folder:

```powershell
mvn test
```

### 3. Change an existing service (brownfield)

Use the completed run id from step 2 as `baseRunId`. The new run starts from those files.

```powershell
$plan2 = Post-Json "/decompose" @{
  requirement  = "Add click analytics and rate limiting to the existing service"
  scenarioHint = "BROWNFIELD"
}
$run2 = Post-Json "/runs" @{
  planId        = $plan2.plan.id
  autonomyLevel = "L2_DELEGATED"
  baseRunId     = $run.id
}
```

Approve the same way. The plan includes an impact-analysis step before design.

### 4. Unclear requirement (ambiguous)

```powershell
Post-Json "/decompose" @{
  requirement = "Make the URL shortener more reliable and faster"
}
```

No concrete capability is named, so the graph stops at a human clarification instead of inventing scope. `summary.scenarioType` is `AMBIGUOUS`.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/host` | OS family, Maven command, Git command |
| POST | `/decompose` | Requirement text to a plan. Body: `requirement` (required), `scenarioHint` (`GREENFIELD`, `BROWNFIELD`, or `AMBIGUOUS`) |
| GET | `/plans` | All plans |
| GET | `/plans/{id}` | One plan, including tasks, dependencies, and the ambiguity register |
| GET | `/plans/{id}/schedule` | Text view of which tasks run together |
| GET | `/plans/{id}/mermaid` | Mermaid source for the graph |
| POST | `/runs` | Start a run. **202**. Body: `planId` or `requirement`, optional `scenarioHint`, `autonomyLevel`, `baseRunId` |
| GET | `/runs` | All runs |
| GET | `/runs/{id}` | Status, counts, and every node |
| GET | `/runs/{id}/events?since=0` | Append-only log after that sequence number |
| GET | `/runs/{id}/decisions` | Who decided what, and why |
| GET | `/runs/{id}/stream?since=0` | Same log as server-sent events |
| POST | `/runs/{id}/pause?reason=` | Finish in-flight nodes; dispatch nothing new |
| POST | `/runs/{id}/resume` | Continue a paused run |
| POST | `/runs/{id}/stop?reason=` | Cancel pending nodes (safe-stop) |
| POST | `/runs/{id}/rollback?reason=` | Undo succeeded nodes, newest first. The run must already be stopped |
| POST | `/runs/{id}/replan?guidance=` | Rebuild the graph from amended text. See outcomes below |
| GET | `/approvals` | Pending approvals. Optional `runId`, `status` (`PENDING`, `APPROVED`, `REJECTED`) |
| GET | `/approvals/{id}` | One approval, including why it stopped |
| POST | `/approvals/{id}/approve?decidedBy=&note=` | Let that node continue |
| POST | `/approvals/{id}/reject?decidedBy=&guidance=` | Fail that node; dependents stay blocked |
| GET | `/policies` | Guardrails. A deny applies at every autonomy level |
| GET | `/metrics` | Success rate, retry rate, rollback rate, MTTR, latency, approval wait |
| GET | `/metrics/runs/{id}` | The same figures for one run |

Autonomy values: `L0_OBSERVE`, `L1_SUPERVISED`, `L2_DELEGATED` (default), `L3_AUTONOMOUS`. Autonomy changes when a person is asked. It does not turn a policy deny into an allow.

`POST /runs/{id}/replan` returns a `status`:

| Status | Meaning |
|---|---|
| `ADMITTED` | The new plan is running |
| `AWAITING_PLAN_APPROVAL` | The plan change itself needs approval |
| `NO_CHANGE` | The amendment produced the same graph |
| `OSCILLATION_DETECTED` | This shape was already seen; the desk refuses to loop |
| `BOUND_REACHED` | Re-plan limit for this run |
| `REJECTED` | The run is not in a state that can be re-planned |

Unknown ids return **404**. Approving an approval that was already decided returns **409**.

## Tests

From `desk`, with `JAVA_HOME` pointing at JDK 21:

```powershell
.\mvnw.cmd test
```
