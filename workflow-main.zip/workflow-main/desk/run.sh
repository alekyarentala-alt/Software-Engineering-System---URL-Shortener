#!/usr/bin/env bash
# Start the review desk on Linux or macOS. Maven comes from the wrapper.
set -euo pipefail
cd "$(dirname "$0")"

if [[ -z "${JAVA_HOME:-}" ]]; then
  for candidate in \
      /usr/lib/jvm/java-21-openjdk-amd64 \
      /usr/lib/jvm/java-21-openjdk \
      /usr/lib/jvm/temurin-21-jdk-amd64; do
    if [[ -x "$candidate/bin/java" ]]; then
      export JAVA_HOME="$candidate"
      break
    fi
  done
fi

exec ./mvnw spring-boot:run "$@"
