# Start the review desk on Windows. Maven comes from the wrapper.
# Usage:
#   .\run.ps1
#   .\run.ps1 "-Dspring-boot.run.arguments=--desk.executor=agent --desk.node-timeout-ms=900000"
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not $env:JAVA_HOME) {
    $roots = @(
        "$env:ProgramFiles\Eclipse Adoptium",
        "$env:ProgramFiles\Java",
        "$env:ProgramFiles\Microsoft"
    )
    foreach ($root in $roots) {
        if (Test-Path $root) {
            $hit = Get-ChildItem $root -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match '21' } |
                Select-Object -First 1
            if ($hit) {
                $env:JAVA_HOME = $hit.FullName
                break
            }
        }
    }
}

if (-not $env:JAVA_HOME) {
    Write-Error "JAVA_HOME is not set and no JDK 21 was found. Install Temurin 21 and set JAVA_HOME."
}

& .\mvnw.cmd spring-boot:run @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
