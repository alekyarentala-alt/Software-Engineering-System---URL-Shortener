package com.reviewflow.desk.plan;

/** Thrown when a produced task graph is structurally invalid. */
public class GraphValidationException extends RuntimeException {

    public GraphValidationException(String message) {
        super(message);
    }
}
