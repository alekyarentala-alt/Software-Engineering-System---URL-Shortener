package com.reviewflow.desk.agent;

import com.reviewflow.desk.execution.ExecutionContext;
import com.reviewflow.desk.reliability.CompensationExecutor;
import com.reviewflow.desk.reliability.CompensationResult;
import com.reviewflow.desk.sandbox.SandboxViolationException;
import com.reviewflow.desk.sandbox.Workspace;
import com.reviewflow.desk.tools.GitTool;
import com.reviewflow.desk.tools.ToolResult;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Real compensation: reverts the commit a node made.
 *
 * <p>Precise rather than approximate. Each node commits separately and records its sha, so undoing
 * one node is one revert of one commit — not an attempt to reconstruct which files a node was
 * responsible for after the fact.
 */
@Component
@ConditionalOnProperty(name = "desk.executor", havingValue = "agent")
public class GitCompensationExecutor implements CompensationExecutor {

    private final GitTool git;
    private final WorkspaceRunner executor;

    public GitCompensationExecutor(GitTool git, WorkspaceRunner executor) {
        this.git = git;
        this.executor = executor;
    }

    @Override
    public CompensationResult compensate(ExecutionContext context) {
        String sha = context.nodeOutputs().get("git.commit");
        if (sha == null) {
            // A node that wrote nothing has nothing to undo. Distinguishing that from a failure
            // matters: reporting it as failed would halt a rollback that is proceeding correctly.
            return CompensationResult.undone(
                    "No commit recorded for " + context.task().id() + "; nothing to undo");
        }

        Workspace workspace;
        try {
            workspace = executor.workspaceFor(context.runId());
        } catch (SandboxViolationException unavailable) {
            return CompensationResult.failed(
                    "Workspace unavailable: " + unavailable.getMessage());
        }

        if (!git.isClean(workspace)) {
            // Reverting onto uncommitted changes produces a tree that is neither the old state nor
            // the new one. Refusing is the outcome a human can still reason about.
            return CompensationResult.failed(
                    "Working tree has uncommitted changes; refusing to revert onto them");
        }

        ToolResult revert = git.revert(workspace, sha);
        return revert.success()
                ? CompensationResult.undone(revert.summary())
                : CompensationResult.failed(revert.summary());
    }
}
