package com.reviewflow.desk.plan;

/**
 * Who owns a task. {@link #HUMAN} is a first-class role, not an absence of one: tasks assigned to
 * HUMAN are the points where the review desk hands control back for oversight.
 */
public enum AgentRole {
    REQUIREMENT_ANALYST,
    CODEBASE_ANALYST,
    ARCHITECT,
    IMPLEMENTER,
    TEST_ENGINEER,
    REVIEWER,
    DOC_WRITER,
    RELEASE_MANAGER,
    HUMAN
}
