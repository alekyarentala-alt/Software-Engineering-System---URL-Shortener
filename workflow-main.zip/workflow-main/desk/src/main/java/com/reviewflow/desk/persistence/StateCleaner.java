package com.reviewflow.desk.persistence;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Wipes all durable state.
 *
 * <p>Exists for test isolation and local resets, and is deliberately not reachable from the HTTP
 * API — a review desk that exposes "delete the entire audit trail" over REST has an audit trail in
 * name only.
 */
@Component
public class StateCleaner {

    private final JdbcTemplate jdbc;

    public StateCleaner(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void deleteEverything() {
        // Children before parents, or the foreign keys reject it.
        jdbc.update("DELETE FROM lineage_entry");
        jdbc.update("DELETE FROM review_gate");
        jdbc.update("DELETE FROM mission_log");
        jdbc.update("DELETE FROM mission_step");
        jdbc.update("DELETE FROM mission");
        jdbc.update("DELETE FROM work_graph");
    }
}
