package com.reviewflow.desk.api;

import com.reviewflow.desk.sandbox.Platform;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * What this process is actually running on.
 *
 * <p>The review desk shows this so an operator on Windows and an operator on Linux can see that the
 * tool names the agents will call match the host. The sandbox already branches on
 * {@link Platform}; this endpoint only reports that choice.
 */
@RestController
@RequestMapping("/api/v1/host")
public class HostController {

    @GetMapping
    public Map<String, String> host() {
        boolean windows = Platform.isWindows();
        return Map.of(
                "family", windows ? "windows" : "unix",
                "os", System.getProperty("os.name", ""),
                "arch", System.getProperty("os.arch", ""),
                "maven", windows ? "mvn.cmd" : "mvn",
                "git", "git",
                "pathSeparator", java.io.File.separator);
    }
}
