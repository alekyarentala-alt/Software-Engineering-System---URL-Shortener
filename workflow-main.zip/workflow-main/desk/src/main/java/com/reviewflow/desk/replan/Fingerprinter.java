package com.reviewflow.desk.replan;

import com.reviewflow.desk.plan.Task;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import org.springframework.stereotype.Component;

/**
 * Content fingerprint of a node: its definition plus the resolved values of everything it reads.
 *
 * <p>Borrowed from build systems, and it is what makes CR4.11 tractable. Staleness becomes a
 * <em>computable</em> property rather than a guess: if a node's definition or any of its inputs
 * changed, its fingerprint changes, and it must run again. Nothing has to be executed to find out.
 *
 * <p>This only works because {@code reads} and {@code writes} are declared up front — the decision
 * made back in the decomposition increment, paying off three increments later.
 *
 * <p><b>Trade-off:</b> an over-broad {@code reads} declaration causes over-invalidation — wasted
 * work, never incorrect work. That is the right direction to be wrong in.
 */
@Component
public class Fingerprinter {

    /**
     * @param resolvedReads the current value behind each key the task declares it reads
     */
    public String forNode(Task task, Map<String, String> resolvedReads) {
        String definition = String.join("|",
                task.id(),
                task.stage().name(),
                task.agentRole().name(),
                task.blastRadius().name(),
                String.join(",", new TreeSet<>(task.reads())),
                String.join(",", new TreeSet<>(task.writes())),
                String.join(";", task.acceptanceCriteria()));

        // Sorted, so map iteration order cannot make an unchanged node look changed.
        StringBuilder inputs = new StringBuilder();
        new TreeMap<>(resolvedReads).forEach((key, value) ->
                inputs.append(key).append('=').append(value).append(';'));

        return sha256(definition + "\0" + inputs);
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(
                    digest.digest(value.getBytes(StandardCharsets.UTF_8))).substring(0, 16);
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is required by the JLS", impossible);
        }
    }
}
