ALTER TABLE mission ADD COLUMN replan_count INT NOT NULL DEFAULT 0;
ALTER TABLE mission ADD COLUMN pending_replan_guidance VARCHAR(4000);
ALTER TABLE mission ADD COLUMN pending_replan_trigger VARCHAR(48);

ALTER TABLE mission_step ADD COLUMN fingerprint VARCHAR(64);

ALTER TABLE work_graph ADD COLUMN version INT NOT NULL DEFAULT 1;
ALTER TABLE work_graph ADD COLUMN supersedes VARCHAR(64);
