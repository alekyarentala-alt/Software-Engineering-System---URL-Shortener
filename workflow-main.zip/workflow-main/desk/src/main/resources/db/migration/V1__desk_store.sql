-- Durable state for the review desk.
-- A mission can sit waiting on a person across a restart, so this store is the record of that wait.

CREATE TABLE work_graph (
    id          VARCHAR(64) PRIMARY KEY,
    created_at  TIMESTAMP    NOT NULL,
    payload     CLOB         NOT NULL
);

CREATE TABLE mission (
    id              VARCHAR(64) PRIMARY KEY,
    graph_id        VARCHAR(64)  NOT NULL,
    autonomy_level  VARCHAR(32)  NOT NULL,
    status          VARCHAR(32)  NOT NULL,
    created_at      TIMESTAMP    NOT NULL,
    started_at      TIMESTAMP,
    ended_at        TIMESTAMP,
    stop_requested  BOOLEAN      NOT NULL DEFAULT FALSE,
    stop_reason     VARCHAR(512),
    CONSTRAINT fk_mission_graph FOREIGN KEY (graph_id) REFERENCES work_graph (id)
);

CREATE INDEX idx_mission_status ON mission (status);

CREATE TABLE mission_step (
    mission_id  VARCHAR(64)  NOT NULL,
    task_id     VARCHAR(128) NOT NULL,
    state       VARCHAR(32)  NOT NULL,
    attempt     INT          NOT NULL,
    started_at  TIMESTAMP,
    ended_at    TIMESTAMP,
    message     VARCHAR(2048),
    outputs     CLOB,
    PRIMARY KEY (mission_id, task_id),
    CONSTRAINT fk_step_mission FOREIGN KEY (mission_id) REFERENCES mission (id)
);

CREATE TABLE mission_log (
    mission_id   VARCHAR(64)  NOT NULL,
    seq          BIGINT       NOT NULL,
    task_id      VARCHAR(128),
    type         VARCHAR(48)  NOT NULL,
    actor        VARCHAR(64),
    message      VARCHAR(2048),
    occurred_at  TIMESTAMP    NOT NULL,
    PRIMARY KEY (mission_id, seq),
    CONSTRAINT fk_log_mission FOREIGN KEY (mission_id) REFERENCES mission (id)
);

CREATE TABLE review_gate (
    id            VARCHAR(64) PRIMARY KEY,
    mission_id    VARCHAR(64)  NOT NULL,
    task_id       VARCHAR(128) NOT NULL,
    task_title    VARCHAR(512),
    blast_radius  VARCHAR(16)  NOT NULL,
    status        VARCHAR(16)  NOT NULL,
    reasons       CLOB,
    policy_ids    VARCHAR(512),
    requested_at  TIMESTAMP    NOT NULL,
    decided_by    VARCHAR(128),
    decided_at    TIMESTAMP,
    guidance      VARCHAR(2048),
    CONSTRAINT fk_gate_mission FOREIGN KEY (mission_id) REFERENCES mission (id)
);

CREATE INDEX idx_gate_status ON review_gate (status);
CREATE INDEX idx_gate_mission ON review_gate (mission_id);

CREATE TABLE lineage_entry (
    id           VARCHAR(64) PRIMARY KEY,
    mission_id   VARCHAR(64)  NOT NULL,
    task_id      VARCHAR(128),
    actor        VARCHAR(128) NOT NULL,
    question     VARCHAR(1024),
    choice       VARCHAR(256),
    rationale    CLOB,
    alternatives CLOB,
    occurred_at  TIMESTAMP    NOT NULL,
    CONSTRAINT fk_lineage_mission FOREIGN KEY (mission_id) REFERENCES mission (id)
);

CREATE INDEX idx_lineage_mission ON lineage_entry (mission_id);
