-- Names the finished mission whose workspace this one continues from.
-- Not a foreign key: a missing seed degrades to an empty workspace instead of rejecting the row.
ALTER TABLE mission ADD COLUMN seed_mission_id VARCHAR(64);
