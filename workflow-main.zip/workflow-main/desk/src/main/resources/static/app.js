/*
 * Review desk. A client of the REST API only — no scheduling logic lives here.
 * Static files, no build step, no CDN, so the same page works on Windows and Linux
 * with the browser that ships on either.
 */
const Desk = (() => {

  const API = '/api/v1';
  const STAGES = [
    ['REQUIREMENTS', 'Requirements'],
    ['CLARIFICATION', 'Clarification'],
    ['IMPACT_ANALYSIS', 'Impact'],
    ['DESIGN', 'Design'],
    ['IMPLEMENTATION', 'Build'],
    ['TESTING', 'Verify'],
    ['REVIEW', 'Review'],
    ['DOCUMENTATION', 'Docs'],
    ['RELEASE_READINESS', 'Release']
  ];
  const AUTONOMY = [
    ['L0_OBSERVE', 'L0 — every action waits'],
    ['L1_SUPERVISED', 'L1 — low-impact work only'],
    ['L2_DELEGATED', 'L2 — ask on high impact'],
    ['L3_AUTONOMOUS', 'L3 — ask on critical only']
  ];
  const MISSION_HINT = {
    greenfield: 'GREENFIELD',
    brownfield: 'BROWNFIELD',
    ambiguous: null
  };

  const state = {
    view: 'missions',
    runId: null,
    plan: null,
    run: null,
    events: [],
    lastSeq: 0,
    sse: null,
    poll: null,
    draft: null
  };

  async function api(path, options) {
    const response = await fetch(API + path, options);
    if (!response.ok) {
      let detail = response.statusText;
      try {
        const body = await response.json();
        detail = body.detail || body.message || body.error || detail;
      } catch (ignored) { /* not every error is JSON */ }
      throw new Error(detail);
    }
    return response.status === 204 ? null : response.json();
  }

  const post = (path) => api(path, { method: 'POST' });

  const esc = (value) => String(value === null || value === undefined ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function ms(value) {
    if (value === null || value === undefined) return '—';
    if (value < 1000) return value + 'ms';
    if (value < 60000) return (value / 1000).toFixed(1) + 's';
    return Math.floor(value / 60000) + 'm ' + Math.round((value % 60000) / 1000) + 's';
  }

  const clock = (iso) => iso ? new Date(iso).toLocaleTimeString() : '—';

  function toast(message, kind) {
    const el = document.getElementById('toast');
    el.textContent = message;
    el.className = 'toast show ' + (kind || '');
    clearTimeout(el._timer);
    el._timer = setTimeout(() => { el.className = 'toast'; }, 4200);
  }

  function reviewer() {
    const name = document.getElementById('reviewer').value.trim();
    return name || 'reviewer';
  }

  function connection(live) {
    document.getElementById('connDot').className = 'dot ' + (live ? 'live' : 'down');
    document.getElementById('connText').textContent = live ? 'live' : 'disconnected';
  }

  function show(view) {
    state.view = view;
    document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
    const page = document.getElementById('view-' + view);
    if (page) page.classList.add('active');
    document.querySelectorAll('.nav').forEach(nav =>
      nav.classList.toggle('active', nav.dataset.view === view));
    if (view !== 'floor') closeStream();
    if (view === 'missions') refreshRuns();
    if (view === 'review') refreshReview();
    if (view === 'reliability') refreshMetrics();
    if (view === 'guardrails') refreshPolicies();
  }

  function fillAutonomy() {
    const options = AUTONOMY.map(([value, label]) =>
      `<option value="${value}"${value === 'L2_DELEGATED' ? ' selected' : ''}>${label}</option>`).join('');
    document.querySelectorAll('select.autonomy').forEach(select => { select.innerHTML = options; });
  }

  async function refreshHost() {
    try {
      const host = await api('/host');
      connection(true);
      document.getElementById('hostLine').textContent =
        host.os + ' · ' + host.arch + ' · maven ' + host.maven + ' · git ' + host.git;
    } catch (error) {
      connection(false);
      document.getElementById('hostLine').textContent = 'Host unavailable';
    }
  }

  async function refreshRuns() {
    try {
      const runs = await api('/runs');
      connection(true);
      renderRuns(runs);
      renderBaselines(runs);
    } catch (error) {
      connection(false);
    }
    refreshBadge();
  }

  function renderBaselines(runs) {
    const select = document.getElementById('baseline');
    const previous = select.value;
    const usable = runs.filter(run => run.status === 'COMPLETED').reverse();
    select.innerHTML = usable.length
      ? '<option value="">Select a finished run</option>' + usable.map(run =>
        `<option value="${esc(run.id)}">${esc(run.id)} — ${esc(run.scenarioType)}</option>`).join('')
      : '<option value="">No finished run yet</option>';
    if (previous && usable.some(run => run.id === previous)) select.value = previous;
  }

  function renderRuns(runs) {
    const el = document.getElementById('runList');
    if (!runs.length) {
      el.innerHTML = '<p class="empty">No runs yet. Read a requirement, then admit the plan.</p>';
      return;
    }
    el.innerHTML = runs.slice().reverse().map(run => `
      <button class="run-row" data-act="open" data-id="${esc(run.id)}">
        <span class="mono">${esc(run.id)}</span>
        <span>${esc(run.scenarioType)}</span>
        <span class="status s-${esc(run.status)}">${esc(run.status)}</span>
        <span>${run.counts.succeeded}/${run.counts.total}</span>
        <span>${ms(run.durationMs)}</span>
      </button>`).join('');
  }

  async function readMission(mission) {
    const text = document.getElementById('text-' + mission).value.trim();
    if (!text) { toast('Write the requirement first.', 'err'); return; }
    const baseRunId = mission === 'brownfield' ? document.getElementById('baseline').value : '';
    if (mission === 'brownfield' && !baseRunId) {
      toast('Brownfield needs a finished run to continue from.', 'err');
      return;
    }
    const autonomy = document.querySelector('select.autonomy[data-mission="' + mission + '"]').value;
    const body = { requirement: text };
    if (MISSION_HINT[mission]) body.scenarioHint = MISSION_HINT[mission];
    try {
      const result = await api('/decompose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      state.draft = { result, mission, autonomy, baseRunId: baseRunId || null };
      renderAdmission();
      document.getElementById('admission').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (error) {
      toast('Could not read the requirement: ' + error.message, 'err');
    }
  }

  function renderAdmission() {
    const box = document.getElementById('admission');
    const { result } = state.draft;
    const plan = result.plan;
    const req = plan.requirement;
    const summary = result.summary;
    const ambiguities = req.ambiguities || [];
    const byStage = {};
    plan.tasks.forEach(task => {
      (byStage[task.stage] = byStage[task.stage] || []).push(task);
    });

    box.classList.remove('hidden');
    box.innerHTML = `
      <p class="kicker">Nothing has executed</p>
      <h2>Admit this plan</h2>
      <p>${esc(req.normalisedStatement)}</p>
      <div class="admit-grid">
        <div>
          <div class="kv">
            <div class="k">Scenario</div><div class="v">${esc(summary.scenarioType)}</div>
            <div class="k">Tasks</div><div class="v">${summary.taskCount}</div>
            <div class="k">Dependencies</div><div class="v">${summary.dependencyCount}</div>
            <div class="k">Parallel width</div><div class="v">${summary.maxParallelism}</div>
            <div class="k">Needs a person</div>
            <div class="v">${esc((summary.humanApprovalTasks || []).join(', ') || 'none')}</div>
            <div class="k">High risk</div>
            <div class="v">${esc((summary.highRiskTasks || []).join(', ') || 'none')}</div>
          </div>
          ${(req.assumedExisting || []).length ? `
            <p class="hint">Assumed already in the codebase: ${esc(req.assumedExisting.join(', '))}.
              Impact analysis has to confirm that.</p>` : ''}
          <h3>Ambiguity register</h3>
          ${ambiguities.length ? ambiguities.map(item => `
            <div class="ambiguity">
              <strong>${esc(item.term)}</strong>
              <div>${esc(item.question)}</div>
              <ul class="options">${(item.options || []).map(option =>
                '<li>' + esc(option) + '</li>').join('')}</ul>
            </div>`).join('') : '<p class="empty">No vague terms. The request names concrete work.</p>'}
        </div>
        <div>
          <h3>Stages in this plan</h3>
          <div class="stage-preview">
            ${STAGES.filter(([id]) => byStage[id]).map(([id, label]) =>
              `<span class="chip${byStage[id].some(task => task.requiresHumanApproval) ? ' human' : ''}">${
                esc(label)} · ${byStage[id].length}</span>`).join('')}
          </div>
          <ul class="notes">${(plan.planningNotes || []).map(note =>
            '<li>' + esc(note) + '</li>').join('')}</ul>
        </div>
      </div>
      <div class="admit-actions">
        <button class="btn solid" data-act="admit">Admit and run</button>
        <button class="btn quiet" data-act="discard">Discard</button>
      </div>`;
  }

  async function admit() {
    if (!state.draft) return;
    const button = document.querySelector('[data-act="admit"]');
    if (button) button.disabled = true;
    try {
      const run = await api('/runs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: state.draft.result.plan.id,
          autonomyLevel: state.draft.autonomy,
          baseRunId: state.draft.baseRunId
        })
      });
      toast('Plan admitted. Run ' + run.id + ' is in motion.', 'ok');
      state.draft = null;
      document.getElementById('admission').classList.add('hidden');
      openRun(run.id);
    } catch (error) {
      toast('Could not start: ' + error.message, 'err');
      if (button) button.disabled = false;
    }
  }

  function discard() {
    state.draft = null;
    document.getElementById('admission').classList.add('hidden');
    document.getElementById('admission').innerHTML = '';
  }

  async function openRun(runId) {
    state.runId = runId;
    state.events = [];
    state.lastSeq = 0;
    state.plan = null;
    show('floor');
    document.getElementById('floorTitle').textContent = runId;
    await loadRun();
    openStream(runId);
  }

  async function loadRun() {
    if (!state.runId) return;
    try {
      const run = await api('/runs/' + state.runId);
      state.run = run;
      connection(true);
      if (!state.plan || state.plan.plan.id !== run.planId) {
        state.plan = await api('/plans/' + run.planId);
      }
      renderFloor(run);
      const [approvals, decisions] = await Promise.all([
        api('/approvals?runId=' + state.runId),
        api('/runs/' + state.runId + '/decisions')
      ]);
      renderFloorApprovals(approvals.filter(item => item.status === 'PENDING'));
      renderDecisions(decisions);
    } catch (error) {
      connection(false);
    }
    refreshBadge();
  }

  function renderFloor(run) {
    document.getElementById('floorStatus').className = 'status s-' + run.status;
    document.getElementById('floorStatus').textContent = run.status;
    document.getElementById('floorReq').textContent = state.plan
      ? state.plan.plan.requirement.rawText : '';
    const counts = run.counts;
    const chip = (label, value) => value > 0
      ? `<span class="count-chip"><b>${value}</b>${label}</span>` : '';
    document.getElementById('floorCounts').innerHTML =
      `<span class="count-chip"><b>${counts.total}</b>total</span>` +
      chip('succeeded', counts.succeeded) +
      chip('running', counts.running) +
      chip('awaiting you', counts.awaitingApproval) +
      chip('retrying', counts.retrying) +
      chip('degraded', counts.degraded) +
      chip('failed', counts.failed) +
      chip('blocked', counts.blocked) +
      chip('rolled back', counts.rolledBack) +
      chip('pending', counts.pending);
    renderStages(run);
    renderBatches();
  }

  function renderStages(run) {
    const byId = {};
    run.nodes.forEach(node => { byId[node.taskId] = node; });
    const tasks = state.plan ? state.plan.plan.tasks : [];
    document.getElementById('stageBoard').innerHTML = STAGES.map(([id, label]) => {
      const inStage = tasks.filter(task => task.stage === id);
      if (!inStage.length) return '';
      return `<div class="stage"><h3>${esc(label)}</h3>${inStage.map(task => {
        const node = byId[task.id] || { state: 'PENDING', taskId: task.id };
        const cls = node.completedDegraded ? 'DEGRADED' : node.state;
        return `<button class="work n-${esc(cls)}" data-act="inspect" data-id="${esc(task.id)}">
          <div class="id">${esc(task.id)}</div>
          <div class="meta">${esc(node.state)}${node.durationMs ? ' · ' + ms(node.durationMs) : ''}</div>
        </button>`;
      }).join('')}</div>`;
    }).join('');
  }

  function renderBatches() {
    const levels = state.plan ? state.plan.plan.executionLevels || [] : [];
    document.getElementById('batches').innerHTML = levels.map((ids, index) =>
      `<span class="batch">Batch ${index + 1}: ${esc(ids.join(', '))}</span>`).join('');
  }

  function eventClass(type) {
    if (/FAILED|DENIED|EXHAUSTED|TIMED_OUT|REJECTED/.test(type)) return 'evt-fail';
    if (/AWAITING|RETRY|DEGRADED|FALLBACK|PAUSED|STOP/.test(type)) return 'evt-warn';
    if (/SUCCEEDED|COMPLETED|GRANTED/.test(type)) return 'evt-ok';
    return '';
  }

  function renderEvents() {
    const log = document.getElementById('eventLog');
    const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 60;
    log.innerHTML = state.events.map(event => `
      <div class="log-row ${eventClass(event.type)}">
        <span class="seq">${event.seq}</span>
        <span class="type">${esc(event.type)}</span>
        <span>${esc(event.taskId ? event.taskId + ' — ' : '')}${esc(event.message || '')}</span>
      </div>`).join('');
    document.getElementById('eventCount').textContent = state.events.length + ' entries';
    if (atBottom) log.scrollTop = log.scrollHeight;
  }

  function renderDecisions(decisions) {
    const el = document.getElementById('decisionLog');
    if (!decisions.length) {
      el.innerHTML = '<p class="empty">No decisions recorded yet.</p>';
      return;
    }
    el.innerHTML = decisions.map(decision => `
      <div class="decision">
        <span class="who">${esc(decision.actor)}</span>
        ${decision.taskId ? ' · <span class="mono">' + esc(decision.taskId) + '</span>' : ''}
        · <strong>${esc(decision.choice)}</strong>
        <div class="why">${esc(decision.question || '')}${decision.question ? ' — ' : ''}${
          esc(decision.rationale || '')}</div>
      </div>`).join('');
  }

  function approvalCard(item) {
    return `<article class="approval">
      <div class="approval-head">
        <strong>${esc(item.taskId)}</strong>
        <span class="pill risk-${esc(item.blastRadius)}">${esc(item.blastRadius)}</span>
        <span class="mono">${esc(item.runId)}</span>
      </div>
      <div>${esc(item.taskTitle || '')}</div>
      <ul class="reasons">${(item.reasons || []).map(reason => '<li>' + esc(reason) + '</li>').join('')}</ul>
      <div class="decide">
        <button class="btn ok" data-act="decide" data-verb="approve" data-id="${esc(item.id)}">Approve</button>
        <button class="btn no" data-act="decide" data-verb="reject" data-id="${esc(item.id)}">Reject</button>
        <input type="text" id="g-${esc(item.id)}" placeholder="Why — recorded either way">
      </div>
    </article>`;
  }

  function renderFloorApprovals(pending) {
    const el = document.getElementById('floorApprovals');
    el.innerHTML = pending.length
      ? `<div class="panel"><div class="section-head"><h2>Waiting on you</h2></div>${
        pending.map(approvalCard).join('')}</div>`
      : '';
  }

  async function refreshReview() {
    try {
      const approvals = await api('/approvals');
      const el = document.getElementById('reviewList');
      el.innerHTML = approvals.length
        ? approvals.map(approvalCard).join('')
        : '<p class="empty">Nothing is waiting on you.</p>';
    } catch (error) {
      toast('Could not load the queue: ' + error.message, 'err');
    }
    refreshBadge();
  }

  async function refreshBadge() {
    try {
      const pending = await api('/approvals');
      const badge = document.getElementById('reviewBadge');
      badge.textContent = pending.length;
      badge.classList.toggle('hidden', pending.length === 0);
    } catch (ignored) { /* badge is optional */ }
  }

  async function decide(approvalId, verb, button) {
    const input = document.getElementById('g-' + approvalId);
    const text = input ? input.value.trim() : '';
    const param = verb === 'approve' ? 'note' : 'guidance';
    const buttons = button.parentElement.querySelectorAll('button');
    buttons.forEach(item => { item.disabled = true; });
    try {
      await post(`/approvals/${approvalId}/${verb}?decidedBy=${
        encodeURIComponent(reviewer())}${text ? '&' + param + '=' + encodeURIComponent(text) : ''}`);
      toast(verb === 'approve' ? 'Approved. The run continues.' : 'Rejected. Dependents stay blocked.',
        verb === 'approve' ? 'ok' : '');
      await Promise.all([state.runId ? loadRun() : Promise.resolve(), refreshReview()]);
    } catch (error) {
      toast('Could not ' + verb + ': ' + error.message, 'err');
      buttons.forEach(item => { item.disabled = false; });
    }
  }

  async function control(action) {
    if (!state.runId) return;
    if (action === 'rollback' &&
        !confirm('Undo every succeeded node, newest first? Only a stopped run can roll back.')) {
      return;
    }
    try {
      const result = await post(`/runs/${state.runId}/${action}?reason=${
        encodeURIComponent('Requested from the review desk')}`);
      toast(result.detail || (action + ' applied'), 'ok');
      loadRun();
    } catch (error) {
      toast(action + ' failed: ' + error.message, 'err');
    }
  }

  async function replan() {
    const guidance = prompt('Amend the requirement. What should change?');
    if (!guidance) return;
    try {
      const outcome = await post(`/runs/${state.runId}/replan?guidance=${encodeURIComponent(guidance)}`);
      toast(outcome.status + (outcome.detail ? ' — ' + outcome.detail : ''), 'ok');
      state.plan = null;
      loadRun();
    } catch (error) {
      toast('Amend failed: ' + error.message, 'err');
    }
  }

  function inspect(taskId) {
    if (!state.run || !state.plan) return;
    const node = state.run.nodes.find(item => item.taskId === taskId);
    const task = state.plan.plan.tasks.find(item => item.id === taskId);
    if (!node || !task) return;
    const deps = state.plan.plan.dependencies;
    const upstream = deps.filter(dep => dep.to === taskId);
    const downstream = deps.filter(dep => dep.from === taskId);
    const nodeEvents = state.events.filter(event => event.taskId === taskId);
    const list = (items) => items.length
      ? items.map(item => '<span class="tag">' + esc(item) + '</span>').join('')
      : '<span class="empty">none</span>';

    document.getElementById('dossierTitle').textContent = taskId;
    document.getElementById('dossierBody').innerHTML = `
      <div class="insp-section"><h4>State</h4>
        <div class="kv">
          <div class="k">State</div><div class="v">${esc(node.state)}</div>
          <div class="k">Attempt</div><div class="v">${node.attempt}</div>
          <div class="k">Duration</div><div class="v">${ms(node.durationMs)}</div>
          <div class="k">Message</div><div class="v">${esc(node.message || '—')}</div>
        </div>
      </div>
      <div class="insp-section"><h4>Work</h4>
        <div class="kv">
          <div class="k">Title</div><div class="v">${esc(task.title)}</div>
          <div class="k">Stage</div><div class="v">${esc(task.stage)}</div>
          <div class="k">Agent</div><div class="v">${esc(task.agentRole)}</div>
          <div class="k">Blast radius</div><div class="v risk-${esc(task.blastRadius)}">${esc(task.blastRadius)}</div>
          <div class="k">Human</div><div class="v">${task.requiresHumanApproval ? 'yes' : 'no'}</div>
        </div>
        <p>${esc(task.description || '')}</p>
      </div>
      <div class="insp-section"><h4>Exit gate checks</h4>
        ${(task.acceptanceCriteria || []).length
          ? '<ul>' + task.acceptanceCriteria.map(item => '<li>' + esc(item) + '</li>').join('') + '</ul>'
          : '<span class="empty">none declared</span>'}
      </div>
      <div class="insp-section"><h4>Reads</h4>${list(task.reads || [])}</div>
      <div class="insp-section"><h4>Writes</h4>${list(task.writes || [])}</div>
      <div class="insp-section"><h4>Depends on</h4>
        ${upstream.length ? upstream.map(dep => `<div><span class="tag">${esc(dep.from)}</span>
          ${esc(dep.reason || '')}</div>`).join('') : '<span class="empty">entry point</span>'}
      </div>
      <div class="insp-section"><h4>Blocks</h4>${list(downstream.map(dep => dep.to))}</div>
      <div class="insp-section"><h4>History</h4>
        ${nodeEvents.length ? nodeEvents.map(event =>
          `<div class="why">${esc(event.type)} — ${esc(event.message || '')}</div>`).join('')
          : '<span class="empty">nothing yet</span>'}
      </div>`;
    document.getElementById('dossier').classList.add('open');
    document.getElementById('scrim').classList.add('open');
  }

  function closeDossier() {
    document.getElementById('dossier').classList.remove('open');
    document.getElementById('scrim').classList.remove('open');
  }

  function metric(label, value, note, tone) {
    const none = value === null || value === undefined;
    return `<div class="metric">
      <div class="label">${esc(label)}</div>
      <div class="value ${none ? 'none' : (tone || '')}">${none ? 'no data' : esc(value)}</div>
      <div class="note">${esc(note || '')}</div>
    </div>`;
  }

  async function refreshMetrics() {
    try {
      const snapshot = await api('/metrics');
      connection(true);
      const runTone = snapshot.runs.successRatePct === null ? ''
        : snapshot.runs.successRatePct >= 80 ? 'good' : snapshot.runs.successRatePct >= 50 ? 'warn' : 'bad';
      document.getElementById('metrics').innerHTML = [
        metric('Run success',
          snapshot.runs.successRatePct === null ? null : snapshot.runs.successRatePct + '%',
          snapshot.runs.completed + ' finished · ' + snapshot.runs.active + ' active', runTone),
        metric('Node success',
          snapshot.nodes.successRatePct === null ? null : snapshot.nodes.successRatePct + '%',
          snapshot.nodes.succeeded + '/' + snapshot.nodes.attempted + ' attempted · '
            + snapshot.nodes.blocked + ' never reached'),
        metric('Retry rate',
          snapshot.reliability.retryRatePct === null ? null : snapshot.reliability.retryRatePct + '%',
          snapshot.reliability.retriesScheduled + ' retries · '
            + snapshot.reliability.fallbacksAttempted + ' fallbacks'),
        metric('MTTR', ms(snapshot.reliability.meanTimeToRecoveryMs),
          snapshot.reliability.recoveredFailures + ' recovered · '
            + snapshot.reliability.unrecoveredFailures + ' not'),
        metric('Rollbacks', snapshot.reliability.nodesRolledBack,
          snapshot.reliability.compensationFailures + ' compensation failures'),
        metric('Run latency', ms(snapshot.latency.meanRunMs),
          'p95 ' + ms(snapshot.latency.p95RunMs) + ' · max ' + ms(snapshot.latency.maxRunMs)),
        metric('Approvals', snapshot.governance.approvalsRequested,
          snapshot.governance.approved + ' granted · ' + snapshot.governance.rejected + ' rejected'),
        metric('Human wait', ms(snapshot.governance.meanWaitMs),
          'max ' + ms(snapshot.governance.maxWaitMs) + ' · not counted as engine latency')
      ].join('');
    } catch (error) {
      connection(false);
      toast('Could not load metrics: ' + error.message, 'err');
    }
  }

  async function refreshPolicies() {
    try {
      const policies = await api('/policies');
      document.getElementById('policyList').innerHTML = policies.map(policy => `
        <article class="policy">
          <h3>${esc(policy.id)} · ${esc(policy.name)}</h3>
          <span class="pill ${policy.effect === 'DENY' ? 's-FAILED'
            : policy.effect === 'REQUIRE_APPROVAL' ? 's-AWAITING_APPROVAL' : 's-PENDING'}">${
              esc(policy.effect)}</span>
          <span class="hint">${esc(policy.category)}</span>
          <p>${esc(policy.rationale)}</p>
        </article>`).join('');
    } catch (error) {
      toast('Could not load guardrails: ' + error.message, 'err');
    }
  }

  function openStream(runId) {
    closeStream();
    try {
      const sse = new EventSource(`${API}/runs/${runId}/stream?since=0`);
      state.sse = sse;
      sse.addEventListener('run-event', (message) => {
        const event = JSON.parse(message.data);
        if (event.seq <= state.lastSeq) return;
        state.lastSeq = event.seq;
        state.events.push(event);
        renderEvents();
        loadRun();
      });
      sse.onopen = () => connection(true);
      sse.onerror = () => connection(false);
    } catch (error) {
      connection(false);
    }
    state.poll = setInterval(() => { if (state.runId && state.view === 'floor') loadRun(); }, 5000);
  }

  function closeStream() {
    if (state.sse) { state.sse.close(); state.sse = null; }
    if (state.poll) { clearInterval(state.poll); state.poll = null; }
    if (state.view !== 'floor') state.runId = null;
  }

  document.addEventListener('DOMContentLoaded', () => {
    const stored = localStorage.getItem('reviewdesk.reviewer');
    if (stored) document.getElementById('reviewer').value = stored;
    document.getElementById('reviewer').addEventListener('change', (event) => {
      localStorage.setItem('reviewdesk.reviewer', event.target.value.trim());
    });
    fillAutonomy();
    document.body.addEventListener('click', (event) => {
      const el = event.target.closest('[data-act]');
      if (!el) return;
      const act = el.dataset.act;
      if (act === 'nav') show(el.dataset.view);
      if (act === 'read') readMission(el.dataset.mission);
      if (act === 'admit') admit();
      if (act === 'discard') discard();
      if (act === 'open') openRun(el.dataset.id);
      if (act === 'refresh-runs') refreshRuns();
      if (act === 'decide') decide(el.dataset.id, el.dataset.verb, el);
      if (act === 'control') control(el.dataset.cmd);
      if (act === 'replan') replan();
      if (act === 'inspect') inspect(el.dataset.id);
      if (act === 'close-dossier') closeDossier();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeDossier();
    });
    refreshHost();
    refreshRuns();
    setInterval(() => { if (state.view === 'missions') refreshRuns(); }, 4000);
    setInterval(() => { if (state.view === 'review') refreshReview(); }, 4000);
  });

  return { show, openRun };
})();
