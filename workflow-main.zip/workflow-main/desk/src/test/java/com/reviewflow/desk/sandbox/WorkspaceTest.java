package com.reviewflow.desk.sandbox;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * The sandbox is the boundary an agent cannot be allowed to cross, so its tests are adversarial
 * rather than illustrative: each one is a way a path can leave a directory it appears to be inside.
 */
class WorkspaceTest {

    @TempDir
    Path tempDir;

    private Workspace workspace() {
        return Workspace.at(tempDir.resolve("ws"));
    }

    // ------------------------------------------------------------------ accepted

    @Test
    void acceptsOrdinaryRelativePaths() {
        Workspace workspace = workspace();

        Path resolved = workspace.resolve("src/main/java/App.java");

        // Compared as paths, not via AssertJ's Path.startsWith: that one canonicalises both sides,
        // which requires the file to exist, and resolve() is precisely for files that do not yet.
        assertThat(resolved.startsWith(workspace.root())).isTrue();
        assertThat(resolved.getFileName().toString()).isEqualTo("App.java");
    }

    @Test
    @DisplayName("dot segments that stay inside are normalised, not rejected")
    void acceptsContainedDotSegments() {
        Workspace workspace = workspace();

        assertThat(workspace.resolve("src/main/../main/App.java"))
                .isEqualTo(workspace.root().resolve("src/main/App.java"));
    }

    @Test
    void acceptsALeadingDotSlash() {
        Workspace workspace = workspace();
        assertThat(workspace.resolve("./pom.xml")).isEqualTo(workspace.root().resolve("pom.xml"));
    }

    // ------------------------------------------------------------------ rejected

    @ParameterizedTest(name = "rejects \"{0}\"")
    @ValueSource(strings = {
            "../escaped.txt",
            "../../etc/passwd",
            "src/../../outside.txt",
            "a/b/../../../c",
            "..",
            "../",
            "./..",
            "foo/./../..",
    })
    @DisplayName("every route out through dot segments is refused")
    void rejectsTraversal(String path) {
        assertThatThrownBy(() -> workspace().resolve(path))
                .isInstanceOf(SandboxViolationException.class);
    }

    @ParameterizedTest(name = "rejects absolute \"{0}\"")
    @ValueSource(strings = {"/etc/passwd", "/tmp/x", "/"})
    void rejectsAbsolutePaths(String path) {
        assertThatThrownBy(() -> workspace().resolve(path))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("Absolute");
    }

    @Test
    @DisplayName("a NUL byte is refused, because it truncates the path below the JVM")
    void rejectsNulBytes() {
        assertThatThrownBy(() -> workspace().resolve("safe.txt\0/../../etc/passwd"))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("NUL");
    }

    @Test
    void rejectsBlankAndNullPaths() {
        assertThatThrownBy(() -> workspace().resolve(null))
                .isInstanceOf(SandboxViolationException.class);
        assertThatThrownBy(() -> workspace().resolve("   "))
                .isInstanceOf(SandboxViolationException.class);
    }

    @Test
    void rejectsOverlongPaths() {
        assertThatThrownBy(() -> workspace().resolve("a/".repeat(2000) + "file.txt"))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("exceeds");
    }

    @Test
    void rejectsTheWorkspaceRootItself() {
        assertThatThrownBy(() -> workspace().resolve("."))
                .isInstanceOf(SandboxViolationException.class);
    }

    // ------------------------------------------------------------------ portability

    /**
     * These run on every platform, not only Windows. A workspace that cannot be checked out on
     * Windows is a defect wherever it was produced, and refusing the same names everywhere is what
     * makes a run reproducible across hosts.
     */
    @ParameterizedTest(name = "rejects backslash in \"{0}\"")
    @ValueSource(strings = {"docs\\readme.md", "src\\..\\..\\escaped.txt", "a\\b"})
    @DisplayName("backslash is refused: a separator on Windows, a filename character elsewhere")
    void rejectsBackslashes(String path) {
        // Accepting it would mean one string naming two different files depending on the host —
        // and on Windows, "src\..\..\escaped.txt" is a traversal the dot-segment check never sees.
        assertThatThrownBy(() -> workspace().resolve(path))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("Backslash");
    }

    @ParameterizedTest(name = "rejects reserved name \"{0}\"")
    @ValueSource(strings = {"NUL", "nul", "docs/con.md", "COM1", "src/aux.java", "prn.txt"})
    @DisplayName("Windows device names are refused, because writing to one discards the content")
    void rejectsReservedDeviceNames(String path) {
        // Opening NUL on Windows succeeds and swallows everything written to it, so a node could
        // "produce" its declared output, satisfy its exit gate, and have written nothing at all.
        assertThatThrownBy(() -> workspace().resolve(path))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("reserved");
    }

    @ParameterizedTest(name = "accepts \"{0}\"")
    @ValueSource(strings = {"docs/console.md", "src/Contact.java", "auxiliary.txt", "communication"})
    @DisplayName("names that merely begin with a device name are ordinary files")
    void doesNotOverBlockNamesResemblingDeviceNames(String path) {
        // A rule that fires on Contact.java would be switched off within a day, which is worse
        // than not having it.
        assertThat(workspace().resolve(path)).isNotNull();
    }

    @ParameterizedTest(name = "rejects trailing whitespace or dot in \"{0}\"")
    @ValueSource(strings = {"docs/evidence.", "docs/readme.md ", "trailing./file.txt"})
    @DisplayName("a segment Windows would silently rename is refused")
    void rejectsSegmentsWindowsWouldStrip(String path) {
        // Windows drops the trailing dot or space, so "evidence." and "evidence" are one file and
        // a containment check on the requested string stops meaning anything.
        assertThatThrownBy(() -> workspace().resolve(path))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("dot or space");
    }

    // ------------------------------------------------------------------ symlinks

    @Test
    @DisplayName("a symlinked file pointing outside is refused despite normalising cleanly")
    void rejectsSymlinkedFileEscape() throws IOException {
        Workspace workspace = workspace();
        Path outside = Files.createFile(tempDir.resolve("outside.txt"));
        Path link = workspace.root().resolve("inside.txt");

        try {
            Files.createSymbolicLink(link, outside);
        } catch (UnsupportedOperationException | IOException unsupported) {
            return; // Filesystem does not support links; nothing to assert.
        }

        // "inside.txt" normalises to a path under the root. Only the real path reveals the escape.
        assertThatThrownBy(() -> workspace.resolve("inside.txt"))
                .isInstanceOf(SandboxViolationException.class)
                .hasMessageContaining("link");
    }

    @Test
    @DisplayName("a new file under a symlinked directory is refused")
    void rejectsSymlinkedDirectoryEscape() throws IOException {
        Workspace workspace = workspace();
        Path outsideDir = Files.createDirectories(tempDir.resolve("elsewhere"));
        Path link = workspace.root().resolve("linked");

        try {
            Files.createSymbolicLink(link, outsideDir);
        } catch (UnsupportedOperationException | IOException unsupported) {
            return;
        }

        // The file does not exist yet, so only the parent's real path can catch this.
        assertThatThrownBy(() -> workspace.resolve("linked/new-file.txt"))
                .isInstanceOf(SandboxViolationException.class);
    }

    // ------------------------------------------------------------------ setup

    @Test
    void createsTheWorkspaceIfAbsent() {
        Path target = tempDir.resolve("nested/deeper/ws");
        Workspace workspace = Workspace.at(target);

        assertThat(Files.isDirectory(workspace.root())).isTrue();
    }

    @Test
    @DisplayName("a workspace reached through a symlink is pinned to its real location")
    void resolvesTheRootThroughLinks() throws IOException {
        Path real = Files.createDirectories(tempDir.resolve("real-ws"));
        Path link = tempDir.resolve("link-ws");
        try {
            Files.createSymbolicLink(link, real);
        } catch (UnsupportedOperationException | IOException unsupported) {
            return;
        }

        // Otherwise every later containment check would compare against the link path and a file
        // reached through the real path would look like an escape.
        assertThat(Workspace.at(link).root()).isEqualTo(real.toRealPath());
    }

    @Test
    @DisplayName("relativise is forward-slashed on every platform")
    void relativisesBackToWorkspacePaths() {
        Workspace workspace = workspace();
        Path resolved = workspace.resolve("docs/readme.md");

        // Evidence keys are matched against the paths a blueprint declared, which are written with
        // forward slashes. Returning "docs\readme.md" on Windows would make a gate fail to
        // recognise the artifact its own node had just produced.
        assertThat(workspace.relativise(resolved)).isEqualTo("docs/readme.md");
    }
}
