package com.reviewflow.desk.plan;

import static org.assertj.core.api.Assertions.assertThat;

import com.reviewflow.desk.requirement.FeatureIndex;
import com.reviewflow.desk.requirement.Requirement;
import com.reviewflow.desk.requirement.BriefParser;
import com.reviewflow.desk.requirement.ScenarioType;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class DecompositionPlannerTest {

    private final BriefParser normalizer =
            new BriefParser(new FeatureIndex());
    private final WorkBreakdown planner = new WorkBreakdown();

    private Plan plan(String requirement) {
        return planner.decompose(normalizer.normalize(requirement));
    }

    private static List<String> ids(Plan plan) {
        return plan.tasks().stream().map(Task::id).toList();
    }

    private static int levelOf(Plan plan, String taskId) {
        List<List<String>> levels = plan.executionLevels();
        for (int i = 0; i < levels.size(); i++) {
            if (levels.get(i).contains(taskId)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean hasEdge(Plan plan, String from, String to) {
        return plan.dependencies().stream()
                .anyMatch(edge -> edge.from().equals(from) && edge.to().equals(to));
    }

    @Nested
    @DisplayName("greenfield")
    class Greenfield {

        private final Plan plan = plan("Build a URL shortener service with shorten and redirect APIs");

        @Test
        void coversTheFullLifecycle() {
            assertThat(ids(plan)).contains(
                    WorkBreakdown.REQ_NORMALISE,
                    WorkBreakdown.ARCH_BASELINE,
                    "DESIGN_" + FeatureIndex.LINK_CREATION,
                    "IMPL_" + FeatureIndex.LINK_CREATION,
                    "TEST_" + FeatureIndex.LINK_CREATION,
                    WorkBreakdown.INTEGRATION_TEST,
                    WorkBreakdown.DOCUMENTATION,
                    WorkBreakdown.CODE_REVIEW,
                    WorkBreakdown.RELEASE_READINESS);
        }

        @Test
        @DisplayName("omits the conditional stages that do not apply")
        void hasNoImpactAnalysisOrClarification() {
            assertThat(ids(plan))
                    .doesNotContain(WorkBreakdown.IMPACT_ANALYSIS, WorkBreakdown.CLARIFY);
        }

        @Test
        @DisplayName("capability dependencies become task ordering")
        void ordersRedirectAfterLinkCreation() {
            assertThat(hasEdge(plan,
                    "IMPL_" + FeatureIndex.LINK_CREATION,
                    "IMPL_" + FeatureIndex.REDIRECT)).isTrue();

            assertThat(levelOf(plan, "IMPL_" + FeatureIndex.REDIRECT))
                    .isGreaterThan(levelOf(plan, "IMPL_" + FeatureIndex.LINK_CREATION));
        }

        @Test
        @DisplayName("independent feature designs dispatch in parallel")
        void designBranchesRunInParallel() {
            assertThat(levelOf(plan, "DESIGN_" + FeatureIndex.LINK_CREATION))
                    .isEqualTo(levelOf(plan, "DESIGN_" + FeatureIndex.REDIRECT));
            assertThat(plan.maxParallelism()).isGreaterThan(1);
        }

        @Test
        @DisplayName("documentation depends on implementation, not on testing")
        void documentationDoesNotQueueBehindTests() {
            assertThat(hasEdge(plan, WorkBreakdown.INTEGRATION_TEST,
                    WorkBreakdown.DOCUMENTATION)).isFalse();
            assertThat(hasEdge(plan, "IMPL_" + FeatureIndex.REDIRECT,
                    WorkBreakdown.DOCUMENTATION)).isTrue();
        }

        @Test
        @DisplayName("schema and hot-path work is flagged for approval")
        void marksHighRiskTasksForApproval() {
            assertThat(plan.tasks())
                    .filteredOn(Task::requiresHumanApproval)
                    .extracting(Task::id)
                    .contains("SCHEMA_" + FeatureIndex.LINK_CREATION,
                            "IMPL_" + FeatureIndex.REDIRECT,
                            WorkBreakdown.RELEASE_READINESS);
        }

        @Test
        void everyTaskHasAcceptanceCriteria() {
            assertThat(plan.tasks()).allSatisfy(task ->
                    assertThat(task.acceptanceCriteria()).isNotEmpty());
        }

        @Test
        @DisplayName("every dependency records why it exists")
        void everyEdgeIsJustified() {
            assertThat(plan.dependencies()).allSatisfy(edge ->
                    assertThat(edge.reason()).isNotBlank());
        }
    }

    @Nested
    @DisplayName("brownfield")
    class Brownfield {

        private final Plan plan = plan("Add click analytics and rate limiting to the existing service");

        @Test
        void insertsImpactAnalysisBeforeDesign() {
            assertThat(ids(plan)).contains(WorkBreakdown.IMPACT_ANALYSIS);
            assertThat(hasEdge(plan, WorkBreakdown.IMPACT_ANALYSIS,
                    WorkBreakdown.ARCH_BASELINE)).isTrue();
            assertThat(levelOf(plan, WorkBreakdown.IMPACT_ANALYSIS))
                    .isLessThan(levelOf(plan, WorkBreakdown.ARCH_BASELINE));
        }

        @Test
        @DisplayName("does not re-plan capabilities that already exist")
        void doesNotRebuildPrerequisites() {
            assertThat(ids(plan)).doesNotContain(
                    "IMPL_" + FeatureIndex.LINK_CREATION,
                    "IMPL_" + FeatureIndex.REDIRECT);
            assertThat(plan.requirement().assumedExisting())
                    .contains(FeatureIndex.LINK_CREATION, FeatureIndex.REDIRECT);
        }

        @Test
        @DisplayName("serialises the two features that both edit RedirectController")
        void serialisesWriteConflict() {
            String analytics = "IMPL_" + FeatureIndex.CLICK_ANALYTICS;
            String rateLimiting = "IMPL_" + FeatureIndex.RATE_LIMITING;

            assertThat(plan.dependencies())
                    .filteredOn(edge -> edge.kind() == DependencyKind.CONTROL)
                    .extracting(Dependency::to)
                    .contains(rateLimiting);

            assertThat(levelOf(plan, rateLimiting)).isNotEqualTo(levelOf(plan, analytics));
        }

        @Test
        @DisplayName("the reason for the imposed ordering is recorded, not implicit")
        void explainsTheImposedOrdering() {
            assertThat(plan.planningNotes())
                    .anySatisfy(note -> assertThat(note).contains("RedirectController"));
            assertThat(plan.planningNotes())
                    .anySatisfy(note -> assertThat(note).contains("Assumed already present"));
        }
    }

    @Nested
    @DisplayName("ambiguous")
    class Ambiguous {

        private final Plan plan = plan("Make the URL shortener more reliable and faster");

        @Test
        @DisplayName("stops at a human clarification task instead of inventing work")
        void haltsForClarification() {
            assertThat(ids(plan)).containsExactly(
                    WorkBreakdown.REQ_NORMALISE, WorkBreakdown.CLARIFY);
            assertThat(plan.requirement().scenarioType()).isEqualTo(ScenarioType.AMBIGUOUS);
        }

        @Test
        void clarificationIsOwnedByAHuman() {
            Task clarify = plan.tasks().stream()
                    .filter(task -> task.id().equals(WorkBreakdown.CLARIFY))
                    .findFirst()
                    .orElseThrow();

            assertThat(clarify.agentRole()).isEqualTo(AgentRole.HUMAN);
            assertThat(clarify.requiresHumanApproval()).isTrue();
        }

        @Test
        void explainsWhyPlanningStopped() {
            assertThat(plan.planningNotes())
                    .anySatisfy(note -> assertThat(note).contains("no concrete capability"));
        }
    }

    @Test
    @DisplayName("the same requirement produces a different shape per scenario")
    void scenarioChangesTheGraphShape() {
        String text = "Add click analytics";
        Requirement asGreenfield = normalizer.normalize(text, ScenarioType.GREENFIELD);
        Requirement asBrownfield = normalizer.normalize(text, ScenarioType.BROWNFIELD);

        Plan greenfield = planner.decompose(asGreenfield);
        Plan brownfield = planner.decompose(asBrownfield);

        // Greenfield must build the prerequisites; brownfield assumes them and adds impact analysis.
        assertThat(greenfield.tasks().size()).isGreaterThan(brownfield.tasks().size());
        assertThat(ids(greenfield)).contains("IMPL_" + FeatureIndex.REDIRECT);
        assertThat(ids(brownfield)).contains(WorkBreakdown.IMPACT_ANALYSIS);
    }

    @Test
    @DisplayName("produced graphs are always valid")
    void everyPlanIsAValidGraph() {
        List<String> requirements = List.of(
                "Build a URL shortener service with shorten and redirect APIs",
                "Add click analytics and rate limiting to the existing service",
                "Add caching and authentication with api key",
                "Make the URL shortener more reliable and faster",
                "Add expiry and custom alias support plus click tracking");

        for (String requirement : requirements) {
            Plan produced = plan(requirement);
            // Reconstructing the graph re-runs cycle and reference validation.
            TaskGraph graph = TaskGraph.of(produced.tasks(), produced.dependencies());
            assertThat(graph.executionLevels()).isNotEmpty();
            assertThat(produced.depth()).isPositive();
        }
    }
}
